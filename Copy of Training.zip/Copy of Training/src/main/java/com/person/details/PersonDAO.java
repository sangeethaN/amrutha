package com.person.details;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PersonDAO {
	public List<PersonBean> getAllPerson()
	{
		List<PersonBean> searchlist=new ArrayList<PersonBean>();;
		
		Connection conn =ConnectionManager.getConnection();
		Statement stmt = null;
		PersonBean pb;
		
		ResultSet resultset = null;
		
		
		String query = "select * from T_XBBNHFW_PERSON";
		try {
			
			 stmt = conn.createStatement();
				 resultset = stmt.executeQuery(query);	
				 while(resultset.next()) {
			 			
			 			pb=new PersonBean();
			 			pb.setId(resultset.getInt(1));
			 			pb.setName(resultset.getString(2));
			 			pb.setPhno(resultset.getInt(3));
			 			System.out.println(pb.getName());
			 			searchlist.add(pb);
				 }
		}catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("select catch");
					e.printStackTrace();
				}	
				finally{
					try {
						if(resultset != null)
						resultset.close();
						if(stmt != null)					
						stmt.close();				
						conn.commit();
						if(conn != null)
						conn.close();
					}			
					 catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
				return searchlist;
	}
	
	 public List<PersonBean> getName(String name) {
	  System.out.println(name);
			List<PersonBean> list = new ArrayList<PersonBean>();
			Connection conn =ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			PersonBean pb;
			
			ResultSet resultset = null;
			
			
			String query = "select * from T_XBBNHFW_PERSON where id=?";
			try {
				 stmt = conn.prepareStatement(query);
					stmt.setString(1, name);
				
				// stmt = conn.createStatement();
					 resultset = stmt.executeQuery();	
					 while(resultset.next()) {
				 			
				 			pb=new PersonBean();
				 			pb.setId(resultset.getInt(1));
				 			pb.setName(resultset.getString(2));
				 		pb.setPhno(resultset.getInt(3));
				 			System.out.println(pb.getName());
				 			list.add(pb);
					 }
			}catch (SQLException e) {
						// TODO Auto-generated catch block
				System.out.println(e.getMessage());
						System.out.println("select catch");
						e.printStackTrace();
					}	
				
					return list;
	    	//return list;
	      }	


}
