Create table T_XBBNHFW_PERSON(id int, name varchar(30),phno int);
Insert into T_XBBNHFW_PERSON values(1,'Radha',12345);
Insert into T_XBBNHFW_PERSON values(2,'Gopi',23456);
Insert into T_XBBNHFW_PERSON values(3,'Sangeetha',34567);
Insert into T_XBBNHFW_PERSON values(4,'Amrutha',45678);
select * from T_XBBNHFW_PERSON;
select * from T_XBBNHFW_PERSON where NAME='Radha';