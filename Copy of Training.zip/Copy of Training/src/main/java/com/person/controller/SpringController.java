package com.person.controller;

	import java.util.ArrayList;
import java.util.List;

	import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

	import com.person.details.PersonBean;
import com.person.details.PersonDAO;
@RestController
	@RequestMapping(value = "/persons")

	public class SpringController {
	PersonDAO persondao=new PersonDAO();
 @RequestMapping(value = "/abc" , method = RequestMethod.GET )

 public List<PersonBean> getAllPersons() {
	    	PersonDAO pdao=new PersonDAO();
			List<PersonBean> list = new ArrayList<PersonBean>();
		list=pdao.getAllPerson();
	    	return list;
	      }	
 

 @RequestMapping(value= "/Search",method = RequestMethod.GET )
 public @ResponseBody List<PersonBean> getAllPersons1(@RequestParam ("CHARS") String chars)
 {
	 System.out.println("In controller");
	 return persondao.getName(chars);
 }
 
	}

