package com.blood.controller;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.servlet.login.DetailsDao;
import com.servlet.login.SignUpServletBean;

@RestController
@RequestMapping(value = "/details")
public class controller {

	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
    public List<SignUpServletBean> getDetails() {
		DetailsDao dd = new DetailsDao();
		List<SignUpServletBean> li = dd.details1();		
		return li;
}
}
