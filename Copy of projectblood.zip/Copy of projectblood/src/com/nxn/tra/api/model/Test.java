package com.nxn.tra.api.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel
public class Test {
	private  String Name;
	private  String id;
	private String pswd;
	private String phonenumber;
	private String type;
	private String gender;
	private String place;
	private String trns;
	private String btype;
	private String units;
	private String weight;
	private String bp;
	private String hl;
    public String getDob() {
		return dob;
	}
	public  void setDob(String dob1) {
		this.dob = dob1;
	}
	private String dob;
	public String getName() {
		return Name;
	}
	public void setName(String name1) {
		this.Name = name1;
	}
	public String getId() {
		return id;
	}
	public void setId(String string) {
		this.id = string;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber1) {
		this.phonenumber = phonenumber1;
	}
	public String getUsertype() {
		return type;
	}
	public  void setUsertype(String bloodtype1) {
		this.type = bloodtype1;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender1) {
		this.gender = gender1;
	}
	public String gettransdate() {
		return trns;
	}
	public void settransdate(String medspec1) {
		this.trns = medspec1;
	}

	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getBtype() {
		return btype;
	}
	public void setBtype(String btype) {
		this.btype = btype;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getBp() {
		return bp;
	}
	public void setBp(String bp) {
		this.bp = bp;
	}
	public String getHl() {
		return hl;
	}
	public void setHl(String hl) {
		this.hl = hl;
	}
	

}
