package com.nxn.tra.api.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;

import com.nxn.tra.api.model.Test;
import com.nxn.tra.api.utility.DateFormatter;


public class TestRowMapper implements RowMapper<Test> {

	public Test mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		
	
		
		
		Test testObj =new Test();
		testObj.setId(rs.getString("ID"));
		testObj.setPswd(rs.getString("PASSWORD"));
		testObj.settransdate(rs.getString("TRNSDATE"));
		testObj.setName(rs.getString("NAME"));
		testObj.setUsertype(rs.getString("USER_TYPE"));
		testObj.setDob(rs.getString("DOB"));
		testObj.setGender(rs.getString("GENDER"));
		testObj.setPhonenumber(rs.getString("CONTACT_NUMBER"));
		testObj.setPlace(rs.getString("PLACE"));
		testObj.setUnits(rs.getString("BLOOD_UNITS"));
		testObj.setBtype(rs.getString("BLOOD_TYPE"));
		return testObj;
	}

}
