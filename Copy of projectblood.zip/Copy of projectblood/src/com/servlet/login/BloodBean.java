package com.servlet.login;

public class BloodBean {
private  String bloodtype;
private   String username;
private int unit;
	// TODO Auto-generated method stub
public  String getBloodtype() {
	return bloodtype;
}
public  void setBloodtype(String btype) {
	this.bloodtype = btype;
}
public  String getUsername() {
	return username;
}
public  void setUsername(String uname) {
	this.username = uname;
}
public void setUnits(int int1) {
	// TODO Auto-generated method stub
	this.unit=int1;
	
}
public int getUnits()
{
	return unit;
}
	
}

