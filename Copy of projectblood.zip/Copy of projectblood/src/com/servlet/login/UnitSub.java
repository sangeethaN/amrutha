package com.servlet.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UnitSub extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	           throws ServletException, IOException{
		 System.out.println("in servlet");

			 UnitDao ud=new UnitDao();
			 HttpSession session=request.getSession(false); 
			 String units1=(String) session.getAttribute("unitsa");
	     int unit1=Integer.parseInt(units1);
			 int unit2=Integer.parseInt((String)request.getParameter("pp"));
			 Integer u=new Integer(unit2-unit1);
			 System.out.println(u);
			 String ut=u.toString();
			 String id=request.getParameter("pp1");
			 String ut1=ud.unsub(ut,id);
			 System.out.println("hi");
			 request.setAttribute("Deta", unit1);
			 String place=(String) session.getAttribute("place");
			 String type=(String) session.getAttribute("type");
			 String date=(String) session.getAttribute("date");
			  String id1=(String) session.getAttribute("ids");
			  System.out.println(place+type+date+id1);
			 ud.insert(id1,type,units1,date,place);
		        RequestDispatcher requestDispatcher = request.getRequestDispatcher("Receiver.jsp");
		        requestDispatcher.forward(request, response);
		 
      	}
}
