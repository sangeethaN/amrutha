package com.servlet.login;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

public class AdminReceiver extends HttpServlet{
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		final Logger logger = Logger.getLogger(AdminReceiver.class);
		 logger.info("in AdminReceiver");
    	AdminDonorDao add = new AdminDonorDao();
         List<SignUpServletBean> RDL2 = add.receiverdetails();
         request.setAttribute("DetailsList2", RDL2);
         RequestDispatcher requestDispatcher1 = request.getRequestDispatcher("ReceiverDetails.jsp");
         requestDispatcher1.forward(request, response);

}
}

