package com.servlet.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class AdminDonorDao {
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	public List<SignUpServletBean> donordetails() {
		final Logger logger = Logger.getLogger(AdminDonorDao.class);
		 logger.info("in AdminDonorDao");
		List<SignUpServletBean> details = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * from T_XBBNHBY_DonorMedSpec";
		try {
			 stmt = conn.prepareStatement(searchQuery);	
			
			 resultset = stmt.executeQuery();	
			
			 details = new ArrayList<SignUpServletBean>();
			 try{
			 
			 
			while(resultset.next()) {
				SignUpServletBean B1 = new SignUpServletBean();
				B1.setId(resultset.getString("ID"));
				//B1.setPswd(resultset.getString("PASSWORD"));
				B1.settransdate(resultset.getString("TRNSDATE"));
               // B1.setName(resultset.getString("NAME"));
               // B1.setUsertype(resultset.getString("USER_TYPE"));
               // B1.setDob(resultset.getString("DOB"));
               // B1.setGender(resultset.getString("GENDER"));
              //  B1.setPhonenumber(resultset.getString("CONTACT_NUMBER"));
                 B1.setPlace(resultset.getString("PLACE"));
                 B1.setUnits(resultset.getString("BLOOD_UNITS"));
                 B1.setBtype(resultset.getString("BLOOD_TYPE"));


				details.add(B1);
						
			}
			 
			 
			 }catch(Exception e){
				 System.out.println("ERROR!");
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		
		return details;
		
		
			
	}
	
	public List<SignUpServletBean> receiverdetails() {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List<SignUpServletBean> details = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * from T_XBBNHBY_ReceiverMedSpec";
		try {
			 try {
				stmt = conn.prepareStatement(searchQuery);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}	
			
			 try {
				resultset = stmt.executeQuery();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}	
			
			 details = new ArrayList<SignUpServletBean>();
			 try{
			 
			 
			while(resultset.next()) {
				SignUpServletBean B1 = new SignUpServletBean();
				B1.setId(resultset.getString("ID"));
				//B1.setPswd(resultset.getString("PASSWORD"));
				B1.settransdate(resultset.getString("TRNSDATE"));
               // B1.setName(resultset.getString("NAME"));
               // B1.setUsertype(resultset.getString("USER_TYPE"));
               // B1.setDob(resultset.getString("DOB"));
               // B1.setGender(resultset.getString("GENDER"));
               // B1.setPhonenumber(resultset.getString("CONTACT_NUMBER"));
                 B1.setPlace(resultset.getString("PLACE"));
                 B1.setUnits(resultset.getString("BLOOD_UNITS"));
                 B1.setBtype(resultset.getString("BLOOD_TYPE"));


				details.add(B1);
						
			}
			 
			 
			 }catch(Exception e){
				 System.out.println("ERROR!");
			 }
		
		
		
		return details;
		
		
			
	}
	
	finally{
		try {
			//if(resultset != null)
			//resultset.close();
			if(stmt != null)					
			stmt.close();				
			conn.commit();
			if(conn != null)
			conn.close();
		}			
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	

	}
}


