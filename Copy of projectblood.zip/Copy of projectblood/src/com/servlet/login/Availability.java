package com.servlet.login;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Availability extends HttpServlet
{
public void doGet(HttpServletRequest request, HttpServletResponse response)  
           throws ServletException, IOException{
	 String type=request.getParameter("avail");
	 String units=request.getParameter("ut"); 
	 String place=request.getParameter("pl"); 
	 String date=request.getParameter("dt"); 

       HttpSession session=request.getSession();  
       session.setAttribute("unitsa",units);
       session.setAttribute("type",type);
       session.setAttribute("date",date);
       session.setAttribute("place",place);
	 BloodDao BD = new BloodDao();
        List<SignUpServletBean> DL = BD.availability(type,units,place);
        request.setAttribute("DList", DL);
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("Availability.jsp");
        requestDispatcher.forward(request, response);
   
        	
}
}
 		