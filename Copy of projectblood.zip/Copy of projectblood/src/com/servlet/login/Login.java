package com.servlet.login;


public class Login {
public boolean validate(LoginServletBean loginbean) throws ClassNotFoundException{
       boolean result=false;
       LoginServletDao loginDao = new LoginServletDao();
       result=loginDao.validate(loginbean);
       return result;
}
}



