package com.servlet.login;

import java.sql.Connection;
import org.apache.log4j.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class DetailsDao {

		public List<SignUpServletBean> details(String id){
			final Logger logger = Logger.getLogger(DetailsDao.class);
			//step 3: create statement object 
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			List<SignUpServletBean> details = null;
			ResultSet resultset = null;
			String searchQuery = "SELECT * from T_XBBNHBY_Details where ID = ?";
			try {
				  logger.info("in DAO");
				 stmt = conn.prepareStatement(searchQuery);
				stmt.setString(1, id);	
				
				 resultset = stmt.executeQuery();	
				
				 details = new ArrayList<SignUpServletBean>();
				 try{
				 
				 
				while(resultset.next()) {
					SignUpServletBean B1 = new SignUpServletBean();
					B1.setId(resultset.getString("ID"));
					B1.setPswd(resultset.getString("PASSWORD"));
					B1.settransdate(resultset.getString("TRNSDATE"));
                    B1.setName(resultset.getString("NAME"));
                    B1.setUsertype(resultset.getString("USER_TYPE"));
                    B1.setDob(resultset.getString("DOB"));
                    B1.setGender(resultset.getString("GENDER"));
                    B1.setPhonenumber(resultset.getString("CONTACT_NUMBER"));
                     B1.setPlace(resultset.getString("PLACE"));
                     B1.setUnits(resultset.getString("BLOOD_UNITS"));
                     B1.setBtype(resultset.getString("BLOOD_TYPE"));
System.out.println(B1);

					details.add(B1);
							
				}
				 
				 
				 }catch(Exception e){
					 System.out.println("ERROR!");
				 }
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
			return details;
			
			
				
		}
		
		
		
		
public List<SignUpServletBean> details1(){
			
			//step 3: create statement object 
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			List<SignUpServletBean> details1 = null;
			ResultSet resultset = null;
			String searchQuery = "SELECT * from T_XBBNHBY_Details";
			try {
				 stmt = conn.prepareStatement(searchQuery);
				
				 resultset = stmt.executeQuery();	
				
				 details1 = new ArrayList<SignUpServletBean>();
				 try{
				 
				 
				while(resultset.next()) {
					SignUpServletBean B11 = new SignUpServletBean();
					B11.setId(resultset.getString("ID"));
					B11.setPswd(resultset.getString("PASSWORD"));
					B11.settransdate(resultset.getString("TRNSDATE"));
                    B11.setName(resultset.getString("NAME"));
                    B11.setUsertype(resultset.getString("USER_TYPE"));
                    B11.setDob(resultset.getString("DOB"));
                    B11.setGender(resultset.getString("GENDER"));
                    B11.setPhonenumber(resultset.getString("CONTACT_NUMBER"));
                     B11.setPlace(resultset.getString("PLACE"));
                     B11.setUnits(resultset.getString("BLOOD_UNITS"));
                     B11.setBtype(resultset.getString("BLOOD_TYPE"));


					details1.add(B11);
							
				}
				 
				 
				 }catch(Exception e){
					 System.out.println("ERROR!");
				 }
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
			return details1;
			
			
				
		}
		
		
		
	}



