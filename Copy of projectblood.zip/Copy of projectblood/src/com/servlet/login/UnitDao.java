package com.servlet.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class UnitDao {
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;

	public String unsub(String unit, String id) {

		// step 3: create statement object
		String b1 = null;

		// List<SignUpServletBean> Bloodtype2 = null;
		ResultSet resultset = null;
		String searchQuery = "UPDATE T_XBBNHBY_Details SET  BLOOD_UNITS= ? where ID= ? ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, unit);
			stmt.setString(2, id);
			stmt.executeUpdate();
			b1 = unit;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			b1 = "Error";
		}

		return b1;

	}

	public void insert(String id, String btype,String units,String date,String place) {
		HttpServletRequest request = null;
		System.out.println("in insert1");
		try {
			String searchQuery = "INSERT INTO T_XBBNHBY_ReceiverMedSpec VALUES(?,?,?,?,?) ";
			//SignUpServletBean al = (SignUpServletBean) request.getSession().getAttribute("rbean");
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, id);
			stmt.setString(2, btype);
			stmt.setString(3, units);
			stmt.setString(4, date);
			stmt.setString(5, place);
			stmt.executeUpdate();
System.out.println("received");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {

				if (stmt != null)
					stmt.close();
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
