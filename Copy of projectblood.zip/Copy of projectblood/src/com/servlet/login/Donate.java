package com.servlet.login;

import java.io.IOException;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Donate extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)  
	           throws ServletException, IOException{
		ArrayList<String> al=new ArrayList<String>();
		 String type=request.getParameter("bt");
		 String units=request.getParameter("uni");
		 String date=request.getParameter("dd");
		 String place=request.getParameter("pl");
		 String weight=request.getParameter("wt");
		 String bp1=request.getParameter("bp");
		 String hb=request.getParameter("hl");
         HttpSession session=request.getSession(false);  
         String id=(String)session.getAttribute("ids");  
         String utype="Donor";
		 DonorsDao dd = new DonorsDao();
			boolean f=dd.donate(type,units,date,place,id,utype,weight,bp1,hb);
			SignUpServletBean sb=new SignUpServletBean();
		// BloodDao BD = new BloodDao();
			if(f)
			{
				sb.setId(id);
	          sb.setBtype(type);
	          sb.setUnits(units);
	          sb.setPlace(place);
	          sb.settransdate(date);
	          sb.setBp(bp1);
	          sb.setWeight(weight);
	          sb.setHl(hb);
			}
	        request.setAttribute("DL", sb);
	        RequestDispatcher requestDispatcher = request.getRequestDispatcher("Donation.jsp");
	        requestDispatcher.forward(request, response);
}
}
