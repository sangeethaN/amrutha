CREATE TABLE T_XBBNHBY_LOGIN(id varchar(30),pswd varchar(30),type1 varchar(30));
insert into T_XBBNHBY_LOGIN values ('12345','aaa','admin');
