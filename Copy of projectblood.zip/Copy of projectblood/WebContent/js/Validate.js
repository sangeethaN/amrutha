function Validat()
{
	var x=document.getElementById("id1").value;
	var y=document.getElementById("pass").value;
	if(x.length!="" && y.length!="")
		return true;
	else if(x.length=="" && y.length!="")
		{
	     alert("Enter id");
	     return false;
		}
	else if(x.length!="" && y.length=="")
		{
		alert("Enter password");
		return false;
		}
	else{
		alert("Enter id and password");
		return false;
	}
}
function valid()
{
	var a=document.getElementById("units").value;
	var b=document.getElementById("bp").value;
	var c=document.getElementById("bt").value;
	var d=document.getElementById("hb").value;
	var e=document.getElementById("date").value;
	var f=document.getElementById("weight").value;
    var g=document.getElementById("place").value;
    
 
     if(a.length=="" || b.length=="" || c.length=="" || d.length=="" || e.length=="" || f.length=="" || g.length=="" )
    	{
    	alert("Enter all the fields");
    	return false;
    	}
     if(Number(d)< 11 || Number(f)< 50 || Number(b)>120 || Number(b)<70 )
 	{
 	alert("You are not eligible to donate blood");
 	return false;
 	}
       if(isNaN(a))
    	   {
    	   alert("Enter in numbers");
    	   return false;
    	   }
       if(isNaN(b))
    	   {
    	   alert("Enter in numbers");
    	   return false;
    	   }
       if(isNaN(d))
	   {
	   alert("Enter in numbers");
	   return false;
	   }
       if(isNaN(f))
	   {
	   alert("Enter in numbers");
	   return false;
	   }
    else
    	{
    	return true;
    	}
}

function sign()
{
	var x;
	var y;
	
	x=Document.getElementById("passid").value;
	y=Document.getElementById("repassid").value;
	z=Document.getElementById("num1").value;

	if(x.equals(y))
		{
	      return true;
		}
	if(isNaN(z))
		{
		 alert("Enter in numbers");
		 return false;
		}
	else
		{
		alert("Your password did not match.Type the correct password");
		 return false;
		}
	

}
