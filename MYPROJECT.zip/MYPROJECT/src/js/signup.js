function sign()
{
	var x;
	var y;
	boolean b=false;
	x=Document.getElementById("passid").value;
	y=Document.getElementById("repassid").value;
	if(x==y)
		{
		b= true;
		}
	else
		{
		alert("Your password did not match.Type the correct password");
		b= false;
		}
	return b;
}