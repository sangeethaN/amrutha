package com.servlet.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SignUpServ extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			userdetails(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	private void userdetails(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ClassNotFoundException, ServletException {
		// TODO Auto-generated method stub response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		SignUpServletBean Bean = new SignUpServletBean();
		response.setContentType("text/html");
		String id = insert1();
		String password = request.getParameter("pass");
		String name = request.getParameter("name1");
		String phonenumber = request.getParameter("num1");
		//String type = request.getParameter("type");
		String gender = request.getParameter("ged");
		String dob1 = request.getParameter("dob");
		String btype1=null;
		String place=null;
		String date1=null;
		String unit=null;
		String type=null;
		String bp=null;
		String hl=null;
		String wt=null;
		Bean.setId(id);
		Bean.setPswd(password);
		Bean.setDob(dob1);
		Bean.setName(name);
		Bean.setPhonenumber(phonenumber);
		Bean.setUsertype(type);
		Bean.setGender(gender);
		Bean.setPlace(place);
		Bean.settransdate(date1);
		Bean.setBtype(btype1);
		Bean.setUnits(unit);
		Bean.setHl(hl);
		Bean.setWeight(wt);
		Bean.setHl(hl);
		SignUpServletDao sd = new SignUpServletDao();
		if (sd.insert(Bean)) {
			out.print("<html>");
			out.print("<body><center>");
			out.print("<P>THANK YOU!<BR> REGISTERED SUCCESSFULLY :)</BR> </P>");
		   out.print("<h1>Your id is: </h1>");
		   out.print(Bean.getId());
			out.print("</body></center>");
			out.print("</html>");
		} else {
			out.print("<html>");
			out.print("<body><center>");
			out.print("<P>NOT SUCCESSFUL</BR> </P>");
			out.print("</body></center>");
			out.print("</html>");
		}
	}

	public String insert1() {
		int id = 0;
		Connection conn = ConnectionManager1.getConnection();
		Statement stmt = null;
		String searchQuery = "SELECT count(id) as countsize from T_XBBNHBY_Details";
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(searchQuery);
			while (rs.next()) {
				id = rs.getInt("countsize");
			}
			id++;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.print(id);
		return String.valueOf(id);
	}

}











