package com.servlet.login;

import java.io.IOException;
import org.apache.log4j.Logger;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginServ extends HttpServlet {


		public void doPost(HttpServletRequest request, HttpServletResponse response)  
	               throws ServletException, IOException{
	              try {
	                     validateUser(request, response);
	              } catch (ClassNotFoundException e) {
	                     // TODO Auto-generated catch block
	                     e.printStackTrace();
	              } 
	       }

	       private void validateUser(HttpServletRequest request,
	                     HttpServletResponse response) throws IOException, ClassNotFoundException, ServletException {
	              // TODO Auto-generated method stub
	             LoginServletBean loginBean = new LoginServletBean();
	              Login login = new Login();
	              boolean result = false;
	              
	              response.setContentType("text/html");  
	           PrintWriter out = response.getWriter(); 
	           
	           String id = request.getParameter("name1");
	           String password = request.getParameter("name2");
	           if(id.equals("admin") && password.equals("admin"))
	           {
	        	  
	        	   response.sendRedirect("AdminAction.html"); 
	           }
	           else
	           {
	           HttpSession session=request.getSession();  
	           session.setAttribute("ids",id);
	           
	           loginBean.setId(id);
	           loginBean.setPwd(password);
	           
	           result = login.validate(loginBean);
	           
	           if(result){
	              response.sendRedirect("action.html"); 
	           }
	           else{
	         
	              RequestDispatcher requestDispatcher = request.getRequestDispatcher("index.jsp");
	              requestDispatcher.include(request, response);
	           }
	           
	       }

	
	       }
}
