package com.servlet.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

public class SignUpServletDao {
	public boolean insert(SignUpServletBean al) {
		final Logger logger = Logger.getLogger(SignUpServletDao.class);
		 logger.info("in sIGNUPDao");
		Connection conn = ConnectionManager1.getConnection();
		PreparedStatement stmt = null;
		ResultSet resultset = null;
		boolean b = true;
		String searchQuery = "INSERT INTO T_XBBNHBY_Details VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, al.getId());
			stmt.setString(2, al.getPswd());
			stmt.setString(3, al.getName());
			stmt.setString(4, al.getDob());
			stmt.setString(5,al.getPhonenumber());
			stmt.setString(6, al.getPlace());
			stmt.setString(7, al.getBtype());
			stmt.setString(8, al.getUnits());
			stmt.setString(9, al.gettransdate());
			stmt.setString(10, al.getGender());
			stmt.setString(11, al.getUsertype());
			stmt.setString(12, al.getWeight());
			stmt.setString(13, al.getBp());
			stmt.setString(14, al.getHl());

			int r = stmt.executeUpdate();
			System.out.println(r);
			if (r > 0)
				b = true;
			else
				b = false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (stmt != null)
					stmt.close();
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return b;
	}
}
