package com.servlet.login;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

public class AdminDonor extends HttpServlet{
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	AdminDonorDao add = new AdminDonorDao();
         List<SignUpServletBean> RDL1 = add.donordetails();
         request.setAttribute("DetailsList1", RDL1);
         RequestDispatcher requestDispatcher = request.getRequestDispatcher("DonorDetails.jsp");
         requestDispatcher.forward(request, response);

}
}
