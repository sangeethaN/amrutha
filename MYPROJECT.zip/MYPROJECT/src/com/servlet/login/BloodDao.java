package com.servlet.login;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;




public class BloodDao {
	public List<SignUpServletBean> availability(String str,String unit,String place){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List<SignUpServletBean> Bloodtype2 = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * from T_XBBNHBY_Details where BLOOD_TYPE= ? AND USER_TYPE='Donor' AND BLOOD_UNITS>=TO_NUMBER(?) AND PLACE= ?";

		try {
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, str);	
			stmt.setString(2, unit);
			stmt.setString(3, place);
			
			 resultset = stmt.executeQuery();	
			
			 Bloodtype2 = new ArrayList<SignUpServletBean>();
			 try{
			 
			 
			while(resultset.next()) {
				SignUpServletBean B2 = new SignUpServletBean();
				B2.setId(resultset.getString("ID"));
				B2.setPswd(resultset.getString("PASSWORD"));
				B2.settransdate(resultset.getString("TRNSDATE"));
                B2.setName(resultset.getString("NAME"));
                B2.setBtype(resultset.getString("BLOOD_TYPE"));
                B2.setDob(resultset.getString("DOB"));
                B2.setGender(resultset.getString("GENDER"));
                B2.setPhonenumber(resultset.getString("CONTACT_NUMBER"));
                 B2.setPlace(resultset.getString("PLACE"));
                 B2.setUsertype(resultset.getString("USER_TYPE"));
                 B2.setUnits(resultset.getString("BLOOD_UNITS"));
				Bloodtype2.add(B2);
						
			}
			 
			 }catch(Exception e){
				 System.out.println("Not Available");
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		return Bloodtype2;
		
		
			
	}
	
	
}
