package com.servlet.login;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class DonorsDao {
	final Logger logger = Logger.getLogger(DonorsDao.class);
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
public boolean donate(String bt,String units1, String date,String place,String id,String type, String weight, String bp1, String hb){
		boolean b=false;
		//step 3: create statement object 
	
		//List<DonorsBean> Bloodtype1 = null;
		//int rs = 0;
		try
		{
		String searchQuery = "UPDATE T_XBBNHBY_DETAILS SET BLOOD_TYPE= ?, BLOOD_UNITS= ?, TRNSDATE= ?, PLACE= ?, USER_TYPE= ?,WEIGHT= ?, BP= ?,HB= ? WHERE ID= ?";
	
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, bt);
			stmt.setString(2,units1);
			stmt.setString(3,date);
			stmt.setString(4,place);
			stmt.setString(5,type);
			stmt.setString(6,weight);
			stmt.setString(7,bp1);
			stmt.setString(8,hb);
			stmt.setString(9,id);

			
			
			 stmt.executeUpdate();	
			 System.out.println("UPDATED");
			 logger.info("in DonorDAOdonate");
								b=true;
								insert(id,bt,units1,date,place);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			b=false;
		}	
		
		

		
		
	return b;		
	}
	public void insert(String id,String bt1,String unit,String date1,String place1)
	{
		 logger.info("in DonorDAO");
		try
		{
		String searchQuery = "INSERT INTO T_XBBNHBY_DonorMedSpec VALUES(?,?,?,?,?) ";
	     SignUpServletBean al=new SignUpServletBean();
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, id);
			stmt.setString(2, bt1);
			stmt.setString(3, unit);
			stmt.setString(4, date1);
			stmt.setString(5, place1);
       		 stmt.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

}
