
package com.servlet.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class LoginServletDao {

	public boolean validate(LoginServletBean loginbean) throws ClassNotFoundException {
		final Logger logger = Logger.getLogger(LoginServletDao.class);
		 logger.info("in LoginDao");
		boolean result = false;
		/*
		 * String password = null; String id = null;
		 */

		Connection conn = ConnectionManager1.getConnection();
		PreparedStatement stmt = null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * from T_XBBNHBY_Details WHERE ID= ? and PASSWORD= ? ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, loginbean.getId());
			stmt.setString(2, loginbean.getPwd());
			resultset = stmt.executeQuery();
			if (resultset.next()) {
				result = true;
			} else {
				result = false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (resultset != null)
					resultset.close();
				if (stmt != null)
					stmt.close();
				conn.commit();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
}
