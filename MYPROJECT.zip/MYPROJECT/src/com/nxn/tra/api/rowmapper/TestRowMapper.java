package com.nxn.tra.api.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;

import com.nxn.tra.api.model.Test;
import com.nxn.tra.api.utility.DateFormatter;


public class TestRowMapper implements RowMapper<Test> {

	public Test mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		
	
		
	
		
		

		Test testObj =new Test();
		
		testObj.setId(rs.getString("ID"));
		//B1.setPswd(resultset.getString("PASSWORD"));
		testObj.settransdate(rs.getString("TRNSDATE"));
       // B1.setName(resultset.getString("NAME"));
       // B1.setUsertype(resultset.getString("USER_TYPE"));
       // B1.setDob(resultset.getString("DOB"));
       // B1.setGender(resultset.getString("GENDER"));
      //  B1.setPhonenumber(resultset.getString("CONTACT_NUMBER"));
		testObj.setPlace(rs.getString("PLACE"));
		testObj.setUnits(rs.getString("BLOOD_UNITS"));
		testObj.setBtype(rs.getString("BLOOD_TYPE"));
		return testObj;

	}

}
