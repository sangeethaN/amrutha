package com.nxn.tra.api.model;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<Test> output;
	
	
	public List<Test>  getOutput() {
		return output;
	}
	public void setOutput(List<Test> outputList) {
		this.output = outputList;
	}
	
	
}
