
create table T_XBBNHBY_ReceiverDetails (ID NUM)

insert into T_XBBNHBY_DONORdetails values ('d1','aaa','Amrutha','A1B+VE','28-03-1996','M',9789075358,'11-02-2016','chennai');